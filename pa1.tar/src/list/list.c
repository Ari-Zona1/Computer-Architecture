#include <stdio.h>
#include <stdlib.h>

//Author: Arjan Abazovic
//NetID: aa2386

// Define ListItem structure
typedef struct ListItem {
    int value;
    struct ListItem* nextItem;
} ListItem;

// Allows visibility to other fucntions
int listSize(ListItem* start);

// Display the list
void displayList(ListItem* start) {
    printf("%d :", listSize(start));  // Print size
    for (ListItem* iter = start; iter; iter = iter->nextItem) {
        printf(" %d", iter->value);  // Print value
    }
    printf("\n");  // New line after list display

    // printf("Testing: Displayed the list.\n");
}

// Get list size
int listSize(ListItem* start) {
    int size = 0;
    ListItem* iter = start;
    for (; iter; iter = iter->nextItem, size++);  // Iterate and count

    // printf("Testing: Counted %d items in the list.\n", size);
    
    return size;
}

// Remove item by value
ListItem* removeFromList(ListItem* start, int val) {

    // printf("Testing: Attempting to remove %d from the list.\n", val);

    if (!start) return NULL;  // Empty list

    if (val == start->value) {  // Match at start
        ListItem* toFree = start;
        start = start->nextItem;
        free(toFree);
        return start;
    }

    ListItem* iter = start;
    // Find match
    while (iter->nextItem && val > iter->nextItem->value) {
        iter = iter->nextItem;
    }

    if (iter->nextItem && val == iter->nextItem->value) {  // Found match
        ListItem* toFree = iter->nextItem;
        iter->nextItem = iter->nextItem->nextItem;
        free(toFree);  // Free memory
    }

    // printf("Testing: Removal completed.\n");

    return start;
}

// Allocate memory for new item
ListItem* allocateItem(int val) {
    // printf("Testing: Allocating new item with value %d.\n", val);
    ListItem* newItem = (ListItem*)malloc(sizeof(ListItem));
    if (!newItem) {
        perror("Failed to allocate memory.");  // Error handling
        exit(EXIT_FAILURE);
    }
    newItem->value = val;  // Set value
    newItem->nextItem = NULL;  // No next item initially

    // printf("Testing: Item allocated successfully.\n");
    
    return newItem;
}

// Insert item in sorted list
ListItem* addToList(ListItem* start, int val) {

    // printf("Testing: Attempting to insert %d to the list.\n", val);
    
    ListItem* itemToAdd = allocateItem(val);
    if (!start || val < start->value) {  // Insert at start
        itemToAdd->nextItem = start;
        return itemToAdd;
    }

    if (val == start->value) {  // Value already present
        free(itemToAdd);
        return start;
    }

    ListItem* iter = start;

    // Find insert position
    while (iter->nextItem && val > iter->nextItem->value) {
        iter = iter->nextItem;
    }

    if (!iter->nextItem || val < iter->nextItem->value) {  // Insert at found position
        itemToAdd->nextItem = iter->nextItem;
        iter->nextItem = itemToAdd;
    } else {  // Value already present
        free(itemToAdd);
    }

    // printf("Testing: Insertion completed.\n");

    return start;
}

int main() {

    // printf("Testing: Program started.\n");

    ListItem* start = NULL;  // Start with empty list
    char task;
    int val;

    // Loop for user input
    while (scanf(" %c %d", &task, &val) != EOF) {
        if (task == 'i') {  // Insert operation
            start = addToList(start, val);
        } else if (task == 'd') {  // Delete operation
            start = removeFromList(start, val);
        }
        displayList(start);  // Show updated list
    }

    // Cleanup memory
    while (start) {
        ListItem* next = start->nextItem;
        free(start);
        start = next;
    }

    // printf("Testing: Program finished.\n");

    return 0;  // End of Program
}

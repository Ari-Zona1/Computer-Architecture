#include <stdio.h>
#include <stdlib.h>

//Author: Arjan Abazovic
//NetID: aa2386

//Delcaring BST structure
typedef struct Node {
    int value;                      // Node value
    struct Node *leftChild;         // Left child
    struct Node *rightChild;        // Right child
} Node;

Node* newNode(int value) {
    Node *temp = malloc(sizeof(Node));     // Allocate memory
    temp->value = value;                   // Set node value
    temp->leftChild = NULL;                // Initialize left child to NULL
    temp->rightChild = NULL;               // Initialize right child to NULL

    //printf("Testing: New node created with value: %d\n", value);

    return temp;                           // Return new node
}

Node* getSmallest(Node *currNode) {
    Node *node = currNode;
    while(node->leftChild != NULL) node = node->leftChild; // Traverse to leftmost node

    //printf("Testing: Smallest node found with value: %d\n", node->value);

    return node;                           // Return leftmost (smallest) node
}

void clearTree(Node* currNode) {
    if (currNode) {
        clearTree(currNode->leftChild);    // Recursively clear left subtree
        clearTree(currNode->rightChild);   // Recursively clear right subtree

        //printf("Testing: Freeing node with value: %d\n", currNode->value);

        free(currNode);                    // Free current node
    }
}

Node* addNode(Node *currNode, int value) {
    if (!currNode) return newNode(value);  // If node is NULL, create new node

    //printf("Testing: Inserting value: %d\n", value);

    if (value < currNode->value)           // If value is less than current node
        currNode->leftChild = addNode(currNode->leftChild, value);  // Recur on left subtree
    else if (value > currNode->value)      // If value is greater than current node
        currNode->rightChild = addNode(currNode->rightChild, value); // Recur on right subtree
    return currNode;                       // Return current node after insertion
}

int contains(Node *currNode, int value) {
    if (!currNode) return 0;               // If node is NULL, return 0 (false)

    //printf("Testing: Searching for value: %d\n", value);

    if (currNode->value == value) return 1; // If value matches, return 1 (true)
    if (value < currNode->value)           // If value is less than current node
        return contains(currNode->leftChild, value); // Recur on left subtree
    return contains(currNode->rightChild, value);    // Else recur on right subtree
}

Node* removeNode(Node *currNode, int value) {
    if (!currNode) return currNode;        // If node is NULL, return it

    //printf("Testing: Attempting to delete node with value: %d\n", value);

    if (value < currNode->value)           // If value is less than current node
        currNode->leftChild = removeNode(currNode->leftChild, value);  // Recur on left subtree
    else if (value > currNode->value)      // If value is greater than current node
        currNode->rightChild = removeNode(currNode->rightChild, value); // Recur on right subtree
    else {                                 // If value matches current node
        if (!currNode->leftChild) {        // Node with only right child or no child
            Node *temp = currNode->rightChild;
            free(currNode);
            return temp;
        } else if (!currNode->rightChild) { // Node with only left child
            Node *temp = currNode->leftChild;
            free(currNode);
            return temp;
        }
        Node *temp = getSmallest(currNode->rightChild);  // Node with two children
        currNode->value = temp->value;                   // Copy the inorder successor's value
        currNode->rightChild = removeNode(currNode->rightChild, temp->value);  // Delete the inorder successor
    }
    return currNode;   // Return current node after deletion
}

void printInOrder(Node *currNode) {
    if (currNode) {
        printf("(");                       // Print opening parenthesis before left subtree
        printInOrder(currNode->leftChild); // Recur on left subtree
        printf("%d", currNode->value);     // Print value of current node
        printInOrder(currNode->rightChild);// Recur on right subtree
        printf(")");                       // Print closing parenthesis after right subtree
    }
}

int main() {
    Node *bstRoot = NULL;        // Root of the BST
    char action;                // User action (i, d, s, p)
    int input;                  // User input for value

    while (scanf(" %c", &action) != EOF) {  // Read until EOF
        switch(action) {
            
            case 'i': // Insert
                scanf("%d", &input);
                if (!contains(bstRoot, input)) {
                    bstRoot = addNode(bstRoot, input);
                    puts("inserted");
                } else {
                    puts("not inserted");
                }
                break;
            
            case 'd': // Delete
                scanf("%d", &input);
                if (contains(bstRoot, input)) {
                    bstRoot = removeNode(bstRoot, input);
                    puts("deleted");
                } else {
                    puts("absent");
                }
                break;
            
            case 's': // Search
                scanf("%d", &input);
                puts(contains(bstRoot, input) ? "present" : "absent");
                break;
            
            case 'p': // Print
                printInOrder(bstRoot);
                putchar('\n');
                break;
        }
    }

    clearTree(bstRoot);         // Free memory used by BST

    //printf("Testing: End of Program. Pass!);
    
    return 0;                   //End of Program
}

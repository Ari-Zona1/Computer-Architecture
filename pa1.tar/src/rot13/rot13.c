#include <stdio.h>
#include <ctype.h>

//Author: Arjan Abazovic
//NetID: aa2386

// Applies the ROT13 transformation to a given character.
// If the character is not an alphabet, it returns the character as is.
char rot13(char c) {
    if (isalpha(c)) {                           
        char base = islower(c) ? 'a' : 'A';   

        // printf("Testing: Current character '%c', base '%c'\n", c, base);   // Debugging statement

        return base + (c - base + 13) % 26;     
    }
    return c;                                   
}

// Transforms and prints an entire string using the ROT13 transformation.
void transformString(char *input) {
    for (int i = 0; input[i] != '\0'; i++) {

        // printf("Testing: Processing character '%c'\n", input[i]);  // Debugging statement

        putchar(rot13(input[i]));                
    }
    putchar('\n');                               
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <string>\n", argv[0]);   
        return 1;
    }

    // printf("Testing: Input string is '%s'\n", argv[1]);  // Debugging statement

    transformString(argv[1]);                     

    return 0; //End of program
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Author: Arjan Abazovic
//NetID: aa2386

int main(int argc, char *argv[]) {
    if (argc < 2) {
        // If no arguments provided, exit without printing anything.
        return 0;
    }

    // Selection Sort
    for (int i = 1; i < argc - 1; i++) {
        // Assume the smallest string is at the current index
        int min_idx = i;

        // Loop through the remaining strings to find the smallest one
        for (int j = i + 1; j < argc; j++) {
            // Compare two strings lexicographically
            if (strcmp(argv[j], argv[min_idx]) < 0) {
                min_idx = j;
            }
        }

        // Swap argv[i] and argv[min_idx] if a smaller string was found
        if (i != min_idx) {
            char *temp = argv[i];
            argv[i] = argv[min_idx];
            argv[min_idx] = temp;
        }

        // Testing: Print the current state of argv after each iteration
        //for (int t = 1; t < argc; t++) {
        //    printf("Testing: argv[%d] = %s\n", t, argv[t]);
        //}
    }

    // Print each sorted argument on its own line.
    for (int i = 1; i < argc; i++) {
        printf("%s\n", argv[i]);
    }

    return 0;
}
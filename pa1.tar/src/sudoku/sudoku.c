#include <stdio.h>
#include <stdlib.h>

//Author: Arjan Abazovic
//NetID: aa2386


//Defining boolean like values
#define TRUE 1
#define FALSE 0

// This function aims to validate a completed Sudoku solution.
int validateSudokuSolution(int puzzle[9][9]) {
    int rowIdx = 0;
    
    // Traverse each row and corresponding column to ensure no duplicates.
    while (rowIdx < 9) {
        // printf("Checking row: %d\n", rowIdx); // Debugging line
        int rowChecker[9] = {0}; // Helper array to check for duplicates in the row.
        int colChecker[9] = {0}; // Helper array to check for duplicates in the column.

        int colIdx = 0;
        while (colIdx < 9) {
            // Check for duplicate numbers in the row or column
            // If a number has been seen before in the row or column, it's an invalid solution.
            if (rowChecker[puzzle[rowIdx][colIdx] - 1] != 0 || colChecker[puzzle[colIdx][rowIdx] - 1] != 0) {
                // printf("Duplicate detected at Row: %d, Col: %d\n", rowIdx, colIdx); // Debugging line
                return FALSE;
            }
            rowChecker[puzzle[rowIdx][colIdx] - 1] = 1; 
            colChecker[puzzle[colIdx][rowIdx] - 1] = 1; 
            colIdx++;
        }
        rowIdx++;
    }

    // Validate each of the 3x3 subgrids.
    int startX = 0;
    while (startX < 9) {
        int startY = 0;
        while (startY < 9) {
            // printf("Checking 3x3 subgrid starting at (%d, %d)\n", startX, startY); // Debugging line
            int boxChecker[9] = {0}; // Helper array to check for duplicates in the subgrid.
            
            int x = 0;
            // For every subgrid, check each cell in the 3x3 matrix.
            while (x < 3) {
                int y = 0;
                while (y < 3) {
                    // If a number has been seen before in this subgrid, it's an invalid solution.
                    if (boxChecker[puzzle[startX + x][startY + y] - 1] != 0) {
                        // printf("Duplicate detected in subgrid at (%d, %d)\n", startX + x, startY + y); // Debugging line
                        return FALSE;
                    }
                    boxChecker[puzzle[startX + x][startY + y] - 1] = 1;
                    y++;
                }
                x++;
            }
            startY += 3; // Move to the next subgrid column-wise.
        }
        startX += 3; // Move to the next subgrid row-wise.
    }
    return TRUE; // If we haven't returned FALSE by now, the solution is valid.
}

// This function tries to solve an incomplete Sudoku puzzle.
int canSolveSudoku(int puzzle[9][9]) {
    int rowIdx = 0;
    // Traverse each cell in the Sudoku grid.
    while (rowIdx < 9) {
        int colIdx = 0;
        while (colIdx < 9) {
            // If the current cell is empty, try numbers 1 through 9.
            if (puzzle[rowIdx][colIdx] == 0) {
                // printf("Empty cell found at Row: %d, Col: %d\n", rowIdx, colIdx); // Debugging line
                int num = 1;
                while (num <= 9) {
                    int isValid = TRUE;

                    int k = 0;
                    // Check if the current number exists in the current row or column.
                    while (k < 9) {
                        if (puzzle[rowIdx][k] == num || puzzle[k][colIdx] == num) {
                            isValid = FALSE;
                            break;
                        }
                        k++;
                    }
                    if (!isValid) {
                        num++; 
                        continue;
                    }

                    // Check if the current number is valid in the current 3x3 subgrid.
                    int boxStartRow = (rowIdx / 3) * 3;
                    int boxStartCol = (colIdx / 3) * 3;
                    int x = 0;
                    while (x < 3) {
                        int y = 0;
                        while (y < 3) {
                            if (puzzle[boxStartRow + x][boxStartCol + y] == num) {
                                isValid = FALSE;
                                break;
                            }
                            y++;
                        }
                        if (!isValid) break;
                        x++;
                    }

                    // If the current number is valid, fill it in and try to solve the rest.
                    if (isValid) {
                        // printf("Number %d seems valid. Trying it...\n", num); // Debugging line
                        puzzle[rowIdx][colIdx] = num;
                        if (canSolveSudoku(puzzle)) {
                            return TRUE;
                        }
                        puzzle[rowIdx][colIdx] = 0; // If not solvable, backtrack.
                    }
                    num++;
                }
                return FALSE; // If no number can be placed in the current cell, it's not solvable.
            }
            colIdx++;
        }
        rowIdx++;
    }
    // printf("Sudoku solved successfully!\n"); // Debugging line
    return TRUE; // Every cell is filled correctly.
}

int main(int argc, char *argv[]) {
    // Ensure proper usage.
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <file.txt>\n", argv[0]);
        return 1;
    }

    char *filename = argv[1];
    
    // printf("Reading from file: %s\n", filename); // Debugging line

    FILE *sudoku_file = fopen(filename, "r"); // Open the input file.

    // If the file cannot be opened, print an error and exit.
    if (!sudoku_file) {
        fprintf(stderr, "Error: Cannot open the file %s\n", filename);
        return 1;
    }

    int puzzle[9][9];
    int hasEmptyCell = FALSE;

    // Read the Sudoku puzzle from the file.
    int rowIdx = 0;
    while (rowIdx < 9) {
        int colIdx = 0;
        while (colIdx < 9) {
            char cell;
            if (fscanf(sudoku_file, " %c", &cell) != 1) {
                fclose(sudoku_file);
                fprintf(stderr, "Error: Invalid input format\n");
                return 1;
            }
            if (cell == '_') { // An underscore represents an empty cell.
                puzzle[rowIdx][colIdx] = 0;
                hasEmptyCell = TRUE;
            } else if (cell >= '1' && cell <= '9') {
                puzzle[rowIdx][colIdx] = cell - '0'; // Convert the char digit to an int.
            } else {
                fclose(sudoku_file);
                fprintf(stderr, "Error: Invalid cell value in input\n");
                return 1;
            }
            colIdx++;
        }
        rowIdx++;
    }
    fclose(sudoku_file); // Close the file after reading.

    // printf("Finished reading file.\n"); // Debugging line

    // Check the Sudoku puzzle's status and print the result.
    if (!hasEmptyCell) { // If the puzzle is complete.
        int isValidSolution = validateSudokuSolution(puzzle);
        if (isValidSolution) {
            printf("correct\n");
        } else {
            printf("incorrect\n");
        }
    } else { // If the puzzle is incomplete.
        int canSolve = canSolveSudoku(puzzle);
        if (canSolve) {
            printf("solvable\n");
        } else {
            printf("unsolvable\n");
        }
    }

    // printf("End of program.\n"); // Debugging line

    return 0; //End of program
}

#include <stdio.h>
#include <stdlib.h>

//Author: Arjan Abazovic
//NetID: aa2386

int **readMatrix(FILE *file, int k) {

    // Testing: Entering readMatrix
    // printf("Testing: Entering readMatrix with k = %d\n", k);

    int **matrix = (int **)malloc(k * sizeof(int *));
    for (int i = 0; i < k; i++) {
        matrix[i] = (int *)malloc(k * sizeof(int));
        for (int j = 0; j < k; j++) {
            if (fscanf(file, "%d", &matrix[i][j]) != 1) {
                fprintf(stderr, "Error reading matrix elements from input file\n");
                exit(1);
            }

            // Testing: Matrix element read
            // printf("Testing: matrix[%d][%d] = %d\n", i, j, matrix[i][j]);
        }
    }

    // Testing: Exiting readMatrix
    // printf("Testing: Exiting readMatrix\n");

    return matrix;
}

int **matrixExponentiation(int **matrix, int k, int n) {

    // Testing: Entering matrixExponentiation
    // printf("Testing: Entering matrixExponentiation with k = %d and n = %d\n", k, n);

    if (n == 1 || n == 0) return matrix;

    int **result = (int **)malloc(k * sizeof(int *));
    for (int i = 0; i < k; i++) {
        result[i] = (int *)malloc(k * sizeof(int));
        for (int j = 0; j < k; j++) {
            result[i][j] = matrix[i][j];
        }
    }

    for (int m = 2; m <= n; m++) {

        // Testing: Current multiplication iteration
        // printf("Testing: Matrix multiplication iteration %d\n", m);

        int **temp = (int **)malloc(k * sizeof(int *));
        for (int i = 0; i < k; i++) {
            temp[i] = (int *)malloc(k * sizeof(int));
            for (int j = 0; j < k; j++) {
                temp[i][j] = result[i][j];
            }
        }

        for (int i = 0; i < k; i++) {
            for (int j = 0; j < k; j++) {
                int sum = 0;
                for (int x = 0; x < k; x++) {
                    sum += matrix[i][x] * temp[x][j];
                }
                result[i][j] = sum;
            }
        }

        for (int i = 0; i < k; i++) {
            free(temp[i]);
        }
        free(temp);
    }

    // Testing: Exiting matrixExponentiation
    // printf("Testing: Exiting matrixExponentiation\n");

    return result;
}

void printMatrix(int **matrix, int k) {
    for (int i = 0; i < k; i++) {
        for (int j = 0; j < k; j++) {
            printf("%d", matrix[i][j]);
            if (j < k - 1) printf(" ");
        }
        printf("\n");
    }
}

int main(int argc, char *argv[]) {

    // Testing: Starting program
    // printf("Testing: Program started\n");

    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }

    int k;
    if (fscanf(file, "%d", &k) != 1) {
        fprintf(stderr, "Error reading matrix size from input file\n");
        return 1;
    }

    // Testing: Matrix size read from file
    // printf("Testing: Matrix size read as k = %d\n", k);

    int **matrix = readMatrix(file, k);

    int n;
    if (fscanf(file, "%d", &n) != 1) {
        fprintf(stderr, "Error reading exponent 'n' from input file\n");
        return 1;
    }

    // Testing: Exponent read from file
    // printf("Testing: Exponent read as n = %d\n", n);

    int **result;
    if (n == 0) {
        result = matrixExponentiation(matrix, k, n);
        for (int i = 0; i < k; i++) {
            for (int j = 0; j < k; j++) {
                printf((i == j) ? "1" : "0");
                if (j < k - 1) printf(" ");
            }
            printf("\n");
        }
    } else {
        result = matrixExponentiation(matrix, k, n);
        printMatrix(result, k);
    }

    for (int i = 0; i < k; i++) {
        free(matrix[i]);
        if (n != 0) free(result[i]);
    }
    free(matrix);
    if (n != 0) free(result);

    fclose(file);

    // Testing: Ending program
    // printf("Testing: Program ended\n");
    
    return 0;
}
